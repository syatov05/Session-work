import React from 'react';
import './Footer.css';

function Footer() {
    return (
        <footer>
            <p>&copy; 2024 Кинотеатр. Все права защищены.</p>
        </footer>
    );
}

export default Footer;